import { Point } from '../classes/index';
export declare const IOU_THRESHOLD = 0.4;
export declare const BOX_ANCHORS: Point[];
export declare const MEAN_RGB: [number, number, number];
